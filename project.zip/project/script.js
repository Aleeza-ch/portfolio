document.getElementById('myButton').addEventListener('click', function() {
    document.getElementById('message').textContent = 'Button clicked! JavaScript is working!';
});
